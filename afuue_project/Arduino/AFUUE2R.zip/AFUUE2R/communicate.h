#pragma once

extern int ChangeSigned(int data);
extern int ChangeUnsigned(int data);

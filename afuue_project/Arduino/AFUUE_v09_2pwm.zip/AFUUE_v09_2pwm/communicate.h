#ifndef COMMUNICATE_H
#define COMMUNICATE_H

extern int ChangeSigned(int data);
extern int ChangeUnsigned(int data);

#endif

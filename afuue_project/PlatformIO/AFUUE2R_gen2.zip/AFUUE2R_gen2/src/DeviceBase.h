#pragma once
#include <Parameters.h>
#include <Wire.h>
#include <string>

struct InitializeResult {
    bool success = true;
    bool skipAfter = false;
    std::string errorMessage = "";
};

class DeviceBase {
public:
    virtual const char* GetName() const = 0;
    virtual InitializeResult Initialize(Parameters& params) = 0;
    static bool CheckDevice(TwoWire& wire, uint8_t address) {
        wire.beginTransmission(address);
        return (wire.endTransmission() == 0);
    }
};

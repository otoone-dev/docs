#include "DeviceBase.h"
#include "WaveTable.h"
#include "InputDevices/InputDeviceBase.h"
#include "InputDevices/PressureLPS33.h"
#include "InputDevices/KeyMCP23017.h"
#include "InputDevices/Key.h"

#include "SoundProcessor/WaveGenerator.h"
#include "SoundProcessor/LFO.h"
#include "SoundProcessor/LowPassFilter.h"
#include "SoundProcessor/Noise.h"
#include "SoundProcessor/Delay.h"

#include "OutputDevices/OutputDeviceBase.h"
#if defined(PWMPIN_LOW) && defined(PWMPIN_HIGH)
#include "OutputDevices/Speaker.h"
#endif

#include "OutputDevices/LED.h"
#include "OutputDevices/USB_MIDI.h"
#include "OutputDevices/SerialMIDI.h"

#include "Menu/MenuForKey.h"

#include <Arduino.h>
#include <WiFi.h>
#include <M5Unified.h>

#ifdef HAS_DISPLAY
#include "logo.h"
M5Canvas canvas(&M5.Display);
#endif
#include <vector>
#include <string>

//-----------
#include <Wire.h>
#define I2C_FREQ (400000)

//-----------
const int32_t updateInterval = 5; // ms
const float deltaTime = (updateInterval / portTICK_PERIOD_MS) / 1000.0f; // 前回との差分とってもいいが、処理落ちしなければよいので
 
//---------------------
class System {
public:
    float m_cpuLoad = 0.0f;
    bool m_btnPressed = false;
#ifdef DEBUG
    std::string m_debugMessage;
#endif
    //--------------
    System()
        : m_keys(0)
        , m_parameters()
    {
    }

    //--------------
    void InitI2C() {
#if defined(I2CPIN_SDA) && defined(I2CPIN_SCL)
        Wire.end();
        // バスリカバリとかいう儀式
        pinMode(I2CPIN_SCL, OUTPUT_OPEN_DRAIN);
        pinMode(I2CPIN_SDA, INPUT_PULLUP);
        for (int i = 0; i < 9; i++) {
            digitalWrite(I2CPIN_SCL, LOW);
            delayMicroseconds(5);
            digitalWrite(I2CPIN_SCL, HIGH); 
            delayMicroseconds(5);
        }
        pinMode(I2CPIN_SDA, OUTPUT_OPEN_DRAIN);
        digitalWrite(I2CPIN_SDA, LOW);
        delayMicroseconds(5);
        digitalWrite(I2CPIN_SCL, HIGH);
        delayMicroseconds(5);
        digitalWrite(I2CPIN_SDA, HIGH);
        delayMicroseconds(5);
        // I2C 開始
        Wire.begin(I2CPIN_SDA, I2CPIN_SCL, I2C_FREQ);
#endif
    }

    //--------------
    void Initialize() {
        m_parameters.Initialize();
        
        SetLED(0, 0, 100);
        delay(100);
        SetLED(0, 0, 1);
        delay(100);

        btStop();
        WiFi.mode(WIFI_OFF); 

        InitI2C();

        ClearDisplay(2);
        Display("AFUUE2R", TFT_WHITE, true);
        delay(200);

        SetLED(0, 0, 100);
        delay(100);
        SetLED(0, 0, 1);
        delay(200);

        ClearDisplay(1);

        // 登録順が重要
#ifdef HAS_LPS33
        m_inputDevices.push_back(new PressureLPS33(Wire, PressureLPS33::ReadType::BREATH_AND_BEND));
#endif
#ifdef HAS_MCP23017
        m_inputDevices.push_back(new KeyMCP23017(Wire));
#endif
#if defined(MIDI_OUT_PIN) && defined(MIDI_IN_PIN) && !ARDUINO_USB_CDC_ON_BOOT
        SerialMIDI* serialMIDI = new SerialMIDI(MIDI_OUT_PIN, MIDI_IN_PIN);
        m_inputDevices.push_back(serialMIDI);
#endif

        m_soundProcessors.push_back(new LFO());
        m_soundProcessors.push_back(new WaveGenerator());
        m_soundProcessors.push_back(new LowPassFilter());
        m_soundProcessors.push_back(new Noise());
        m_soundProcessors.push_back(new Delay(8000));

#ifdef LED_PIN
        m_outputDevices.push_back(new LED(LED_PIN));
#endif
#ifdef USE_USBMIDI
        m_outputDevices.push_back(new USB_MIDI());
#endif
#if defined(MIDI_OUT_PIN) && defined(MIDI_IN_PIN) && !ARDUINO_USB_CDC_ON_BOOT
        m_outputDevices.push_back(serialMIDI);
#endif
#if defined(PWMPIN_LOW) && defined(PWMPIN_HIGH)
        m_outputDevices.push_back(new Speaker(PWMPIN_LOW, PWMPIN_HIGH, m_soundProcessors));
#endif
        m_menus.push_back(new MenuForKey());

        int32_t nDevices = 1;
        std::string errorMessage = "";
        // Input Devices
        for (auto& device : m_inputDevices) {
            Display(device->GetName());
            auto result = device->Initialize(m_parameters);
            if (!result.success) {
                errorMessage += result.errorMessage + "\n";
                ErrorLED(nDevices);
                delay(100);
                while (1) {
                    SetLED(10, 10, 10);
                    delay(1000);
                    ESP.restart();
                }
            }
            if (result.skipAfter) {
                break;
            }
            nDevices++;
        }
        //  Sound Processors
        for (auto& processor : m_soundProcessors) {
            processor->Initialize(m_parameters);
        }
        // Output Devices
        for (auto& device : m_outputDevices) {
            Display(device->GetName());
            auto result = device->Initialize(m_parameters);
            if (!result.success) {
                errorMessage += result.errorMessage + "\n";
                ErrorLED(nDevices);
                delay(100);
                while (1) {
                    SetLED(10, 10, 10);
                    delay(1000);
                    ESP.restart();
                }
            }
            if (result.skipAfter) {
                break;
            }
            nDevices++;
        }
        // Menus
        for (auto& menu : m_menus) {
            Display(menu->GetName());
            menu->Initialize(m_parameters);
        }

        if (errorMessage != "") {
            Display(errorMessage.c_str(), TFT_RED);
            while (1) {
                delay(1000);
            }
        }
        SetLED(0, 0, 100);
        delay(100);
        SetLED(0, 0, 1);
        delay(100);
        
        xTaskCreatePinnedToCore(UpdateTask, "UpdateTask", 4096, this, 2, NULL, CORE1);

#ifdef HAS_DISPLAY
        M5.Lcd.setBrightness(10);
#endif
    }
    //--------------
#if defined(NEOPIXEL_PIN)
    void SetLED(uint8_t r, uint8_t g, uint8_t b) {
        rgbLedWrite((uint8_t)NEOPIXEL_PIN, r, g, b);
    }
#else
    void SetLED(uint8_t r, uint8_t g, uint8_t b) {}
#endif

    //--------------
    void ErrorLED(int32_t errNo) {
#ifndef HAS_DISPLAY
        for (int32_t i = 0; i < errNo; i++) {
            delay(200);
            SetLED(255, 0, 0);
            delay(200);
            SetLED(0, 0, 0);
        }
#endif
        delay(1000);
    }

    //--------------
    const std::string& GetDispMessage() const {
        return m_parameters.dispMessage;
    }
    //--------------
    const std::string& GetWaveName() {
        if (m_parameters.IsUSBMIDIEnabled()) {
            char s[32];
            sprintf(s, "No.%03d", m_parameters.GetWaveTableIndex()+1);
            m_waveNoStr = s;
            return m_waveNoStr;
        }
        return m_parameters.info.name;
    }

private:
    std::vector<InputDeviceBase*> m_inputDevices;
    std::vector<OutputDeviceBase*> m_outputDevices;
    std::vector<SoundProcessorBase*> m_soundProcessors;
    std::vector<MenuBase*> m_menus;
    Parameters m_parameters;
    std::string m_waveNoStr;
    Keys m_keys;
    float m_playTime = 0.0f;
    float m_keepNoteTime = 0.0;
    float m_btnPressedTime = 0.0f;
    bool m_btnWasPressed = false;

    //--------------
    void ClearDisplay(float textSize) {
#ifdef HAS_DISPLAY
        M5.Lcd.setTextColor(TFT_WHITE);
        M5.Lcd.setTextSize(textSize);
        M5.Lcd.clearDisplay(TFT_BLACK);
        M5.Lcd.setCursor(0, 0);
#endif
    }
    //--------------
    void Display(const char* message, int color = TFT_WHITE, bool center = false) {
#ifdef HAS_DISPLAY
        M5.Lcd.setTextColor(color);
        if (center) {
            M5.Lcd.drawCenterString(message,
                M5.Lcd.width() / 2, 
                M5.Lcd.height() / 2 - (M5.Lcd.fontHeight(M5.Lcd.getFont()) * M5.Lcd.getTextSizeY()) / 2);
        }
        else {
            M5.Lcd.printf("%s\n", message);
        }
        delay(100);
#endif
    }
public:
    //--------------
    void Update() {
        uint64_t currentTime = millis();
        Message message;
        message.playTime = m_playTime;
        message.keepNoteTime = m_keepNoteTime;
#ifdef DEBUG
        std::string debugMessage = "";
#endif
        // 入力
        for (auto& device : m_inputDevices) {
            device->UpdateInput(m_parameters, message);
#ifdef DEBUG
            if (!m_parameters.debugMessage.empty()) {
                debugMessage += m_parameters.debugMessage + "\n";
                m_parameters.debugMessage = "";
            }
#endif
        }
        if (message.volume < 0.005f) {
            message.playTime = 0.0f;
        }
        else if (message.playTime < 60*60) {
            message.playTime += deltaTime;
        }
        if (message.keepNoteTime < 60*60) {
            message.keepNoteTime += deltaTime;
        }
        if (m_btnPressed) {
            if (!m_btnWasPressed) {
                m_parameters.SetBeep(53.0f, 200, false);
                m_parameters.NextPlayMode();
            }
            m_btnPressedTime += deltaTime;
            if (m_btnPressedTime > 8) {
                m_parameters.SetDispMessage("RESET ALL", 100);
            }
            if (m_btnPressedTime > 10) {
                m_parameters.BeginPreferences(true);{
                    m_parameters.ClearPreferences();
                }
                m_parameters.EndPreferences();
                delay(100);
                ESP.restart();
            }
        }
        else {
            m_btnPressedTime = 0.0f;
        }
        m_btnWasPressed = m_btnPressed;
        {
            // メニュー
            m_keys.Update(message.keyData);
            for (auto& menu : m_menus) {
                menu->Update(m_parameters, m_keys);
#ifdef DEBUG
                if (!m_parameters.debugMessage.empty()) {
                    debugMessage += m_parameters.debugMessage + "\n";
                    m_parameters.debugMessage = "";
                }
#endif
            }
            if (m_parameters.beepTime > 0) {
                if (currentTime < m_parameters.beepTime) {
                    message.volume = (m_parameters.squareBeep ? 0.05f : 0.2f);
                    message.note = m_parameters.beepNote;
                }
                else {
                    m_parameters.beepTime = 0;
                    m_parameters.squareBeep = false;
                    message.volume = 0.0f;
                }
            }
            if (m_parameters.dispTime > 0) {
                if (currentTime < m_parameters.dispTime) {
                    // 表示中
                }
                else {
                    m_parameters.dispTime = 0;
                }
            }
            else {
                m_parameters.dispMessage = "";
            }
        }
        // 出力
        for (auto& device : m_outputDevices) {
            OutputResult result = device->UpdateOutput(m_parameters, message);
            if (result.hasCpuLoad) {
                m_cpuLoad += (result.cpuLoad - m_cpuLoad) * 0.1f;
            }
#ifdef DEBUG
            if (!m_parameters.debugMessage.empty()) {
                debugMessage += m_parameters.debugMessage + "\n";
                m_parameters.debugMessage = "";
            }
#endif
        }
        m_playTime = message.playTime;
        m_keepNoteTime = message.keepNoteTime;
#ifdef DEBUG
        m_debugMessage = debugMessage;
#endif
        if (m_parameters.IsBendEnabled()) {
            // Bend mode
            int32_t b = static_cast<int32_t>(message.bend * 20.0f);
            SetLED(Clamp(20+b, 0, 255), 0, Clamp(-b, 0, 255));
        }
        else {
            // Normal mode
            SetLED(0, 20, 0);
        }
    }

    //--------------
    static void UpdateTask(void *parameter) {
        System *pSystem = static_cast<System *>(parameter);
        TickType_t xLastWakeTime;
        const TickType_t xFrequency = updateInterval / portTICK_PERIOD_MS; // 5ms
        while (1) {
            pSystem->Update();
            xTaskDelayUntil( &xLastWakeTime, xFrequency );
        }
    }
};
System sys;

//---------------------
void setup() {
  sys.Initialize();
}

//---------------------
void loop() {
  static int loopCount = 0;
  M5.update();
#ifdef HAS_DISPLAY
  canvas.clear(TFT_BLACK);
  canvas.setCursor(0, 0);
  canvas.setTextSize(2);
#ifdef DEBUG
  canvas.printf("PLAYING\n%s", sys.m_debugMessage.c_str());
  delay(100);
  canvas.pushSprite(0, 0);
  return;
#else
  static std::string name = "";
  const std::string& currentName = sys.GetWaveName();
  const std::string& dispMessage = sys.GetDispMessage();
  if (name != currentName || !dispMessage.empty()) {
    canvas.clear(TFT_BLACK);
    canvas.setTextSize(2);
    canvas.pushImage(-5, -10, 120, 105, bitmap_logo);
    canvas.setCursor(0, 120 - 30);
    if (!dispMessage.empty()) {
        canvas.printf("\n%s", dispMessage.c_str());
    }
    else {
        if (name != currentName) {
            name = currentName;
            canvas.printf("\n%s", name.c_str());
        }
    }
    canvas.pushSprite(0, 0);
  }
  //canvas.printf("PLAYING\n%3.2f%%\n", sys.m_cpuLoad * 100.0f);
  //canvas.printf("\n%s", sys.GetDispMessage().c_str());
#endif
#endif //HAS_DISPLAY

#ifdef BUTTON_PIN
  if (digitalRead(BUTTON_PIN) == LOW) {
    sys.m_btnPressed = true;
  }
  else {
    sys.m_btnPressed = false;
  }
#endif
  delay(50);
}

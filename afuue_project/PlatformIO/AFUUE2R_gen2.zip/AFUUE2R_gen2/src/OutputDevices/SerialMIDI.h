#pragma once
#include "MIDIBase.h"

class SerialMIDI : public MIDIBase {
public:
    SerialMIDI(gpio_num_t outPin, gpio_num_t inPin)
     : m_outPin(outPin)
     , m_inPin(inPin)
    {}

    const char* GetName() const override { return "MIDIout"; }

    InitializeResult Initialize(Parameters& params) override {
        InitializeResult result;
        Serial2.begin(31250, SERIAL_8N1, m_inPin, m_outPin);
        return result;
    }

    bool UpdateInput(Parameters& params, Message& msg) override {
        if (params.IsMidiEnabled()) {
#ifdef HW_TONEGENERATOR
            //size_t read = Serial2.readBytes(m_recvData, RECVDATA_SIZE);
            size_t read = Serial2.available();
            if (read >= RECVDATA_SIZE) {
                m_overflow = true;
            }
            if (read > 0) {
                read = (read < RECVDATA_SIZE ? read : RECVDATA_SIZE);
                Serial2.readBytes(m_recvData, read);
            }
            ProcessReceivedData(read);
            MIDI_UpdateInput(params, msg);
#endif
        }
        return true;
    }

    OutputResult UpdateOutput(Parameters& params, Message& msg) override {
        if (params.IsMidiEnabled()) {
#ifndef HW_TONEGENERATOR
            MIDI_UpdateOutput(params, msg);
#endif
        }
        return OutputResult{ false, 0.0f };
    }

protected:
    void SendData(const uint8_t* buff, size_t size) override {
        Serial2.write(buff, size);
    }

private:
    gpio_num_t m_outPin;
    gpio_num_t m_inPin;
};

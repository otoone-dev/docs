#pragma once
#include <Arduino.h>
#include <driver/ledc.h>
#include <soc/ledc_struct.h>
#include <SoundProcessor/SoundProcessorBase.h>
#include "OutputDeviceBase.h"

//---------------------------------
/*
    |   write     read   |   write
    |   -->|       -->|  |   -->|
                      |<-- d -->|

    |   read      write  |
    |   -->|       -->|  |
    |      |<-- d ^-->|
*/
#define WAVEOUT_BUFFERMAX (512)
#define WAVEOUT_BUFFERING_SIZE (400)
uint16_t waveOutBuffer[WAVEOUT_BUFFERMAX];
int32_t waveOutBufferWritePos = 0;
int32_t waveOutBufferReadPos = WAVEOUT_BUFFERMAX / 2;
volatile float tickCount = 0;
volatile float volume = 0;
volatile uint64_t cpuLoad = 0;

hw_timer_t* timer = NULL;
volatile uint32_t waveHigh = 0;
volatile uint32_t waveLow = 0;
//---------------------------------
void IRAM_ATTR OnTimer() {
    ledcWriteChannel(LEDC_CHANNEL_1, waveLow);
    ledcWriteChannel(LEDC_CHANNEL_2, waveHigh);
    uint32_t w = waveOutBuffer[waveOutBufferReadPos];
    waveLow = (w & 0xFF);// << 4;
    waveHigh = ((w >> 8) & 0xFF);// << 4;
    waveOutBufferReadPos = (waveOutBufferReadPos + 1) % WAVEOUT_BUFFERMAX;
}

//---------------------------------
class Speaker : public OutputDeviceBase {
public:
    float m_deltaTime;

    Speaker(gpio_num_t low, gpio_num_t high, std::vector<SoundProcessorBase*>& soundProcessors)
    : m_deltaTime(0.0f)
    , m_soundProcessors(soundProcessors)
    , m_lowPin(low)
    , m_highPin(high)
    , m_attack(0.0f)
    , m_squareBeep(false)
    {}

    //--------------
    const char* GetName() const override {
        return "Speaker";
    }

    //--------------
    InitializeResult Initialize(Parameters& params) override {
        InitializeResult result;
        pinMode(m_lowPin, OUTPUT);
        pinMode(m_highPin, OUTPUT);
        // LEDC set up
        ledcAttachChannel(m_highPin, 156250, 8, LEDC_CHANNEL_2);
        ledcAttachChannel(m_lowPin, 156250, 8, LEDC_CHANNEL_1);

        for (int i = 0; i < WAVEOUT_BUFFERMAX; i++) {
            waveOutBuffer[i] = 0x8000;
        }
        xTaskCreatePinnedToCore(CreateWaveTask, "CreateWaveTask", 16384, this, 3, NULL, CORE0); // 波形生成は Core0 が専念

        timer = timerBegin(80*1000*1000 / CLOCK_DIVIDER);
        timerAttachInterrupt(timer, &OnTimer);
        timerAlarm(timer, TIMER_ALARM, true, 0);
        return result;
    }

    //--------------
    OutputResult UpdateOutput(Parameters& params, Message& msg) override {
        volume = msg.volume;
        m_deltaTime = 1.0f / params.samplingRate;
        m_attack = params.info.attackSoftness;
        m_squareBeep = params.squareBeep;

        for (auto& processor : m_soundProcessors) {
            processor->UpdateParameter(params, msg);
        }

        tickCount = CalcFrequency(params.fineTune, msg.note + msg.bend) / params.samplingRate;

#if 0
        char s[64];
        sprintf(s, "%1.2f, %1.1f", msg.volume, msg.ext);
        params.SetDispMessage(s, 100);
#endif
        float load = cpuLoad / 1000000.0f;
        return OutputResult{ true, load / m_deltaTime };
    }

    //--------------
    static void CreateWaveTask(void* parameter) {
        Speaker* pSystem = static_cast<Speaker*>(parameter);

        TickType_t xLastWakeTime;
        const TickType_t xFrequency = 1 / portTICK_PERIOD_MS; // 1ms

        float fmid = 30000.0f;
        const int32_t umid = 32768;
        SoundInfo info;
        while (1) {
            int createCount = 0;
            info.deltaTime = pSystem->m_deltaTime;
            info.squareBeep = pSystem->m_squareBeep;
            uint64_t t = micros();
            while (1) {
                int d = (waveOutBufferWritePos > waveOutBufferReadPos)
                ? waveOutBufferWritePos - waveOutBufferReadPos
                : WAVEOUT_BUFFERMAX + waveOutBufferWritePos - waveOutBufferReadPos;
                if (d > WAVEOUT_BUFFERING_SIZE) {
                    break;
                }
                info.tickCount = tickCount;
                float a = (volume - info.volume);
                info.volume += (a > 0.0f ? a * pSystem->m_attack : a);
                info.skip = false;
                for (auto& processor : pSystem->m_soundProcessors) {
                    processor->ProcessAudio(info);
                    if (info.skip) break;
                }

                int32_t mi = umid + static_cast<int32_t>(info.wave * fmid);
                int32_t i = Clamp(mi, 0, 65535);
                uint16_t w = static_cast<uint16_t>(i);
                waveOutBuffer[waveOutBufferWritePos] = w;
                waveOutBufferWritePos = (waveOutBufferWritePos + 1) % WAVEOUT_BUFFERMAX;
                createCount++;
            }
            
            if (createCount > 0) {
                cpuLoad = (micros() - t) / createCount;
            }
            xTaskDelayUntil( &xLastWakeTime, xFrequency );
        }
    }

private:
    std::vector<SoundProcessorBase*>& m_soundProcessors;
    gpio_num_t m_lowPin;
    gpio_num_t m_highPin;
    float m_attack;
    bool m_squareBeep;
};

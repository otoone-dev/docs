#pragma once
#include "MIDIBase.h"

#include <USB.h>
#include <USBMIDI.h>
USBMIDI MIDI("AFUUE2R");

//----------------
class USB_MIDI : public MIDIBase {
public:
    USB_MIDI() {}

    const char* GetName() const override { return "USB-MIDI"; }

    InitializeResult Initialize(Parameters& params) override {
        InitializeResult result;
        USB.begin();
        MIDI.begin();
        delay(1000);
        m_mounted = tud_mounted();
        if (m_mounted) {
            m_initialized = true;
            params.playMode = PlayMode::USBMIDI_Normal;
            result.skipAfter = true; // 後続の SerialMIDI と Speaker を起動しない
        }
        return result;
    }

    bool UpdateInput(Parameters& params, Message& msg) override {
        if (!m_initialized || !m_mounted) {
            return true;
        }
        uint32_t recvSize = tud_midi_available();
        if (recvSize >= RECVDATA_SIZE) {
            m_overflow = true;
        }
        if (recvSize > 0) {
            int readSize = (recvSize < RECVDATA_SIZE ? recvSize : RECVDATA_SIZE);
            tud_midi_stream_read(m_recvData, readSize);
            ProcessReceivedData(readSize);
            MIDI_UpdateInput(params, msg);
        }
        return true;
    }

    OutputResult UpdateOutput(Parameters& params, Message& msg) override {
        if (!m_initialized) {
            return OutputResult{ false, 0.0f };
        }

        m_mounted = tud_midi_mounted();
        if (m_mounted) {
            MIDI_UpdateOutput(params, msg);
        }
        else {
            params.SetDispMessage("UNMOUNTED", 100);
        }
        return OutputResult{ false, 0.0f };
    }
protected:
    void SendData(const uint8_t* buff, size_t size) override {
        tud_midi_stream_write(0, buff, size);
    }

private:
    bool m_initialized = false;
    bool m_mounted = false;
};

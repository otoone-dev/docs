#pragma once
#include <Arduino.h>
#include "../InputDevices/InputDeviceBase.h"
#include "OutputDeviceBase.h"
#include <vector>
#include <queue>

#define RECVDATA_SIZE (1024)

class MIDIBase : public OutputDeviceBase, public InputDeviceBase {
public:
    MIDIBase() {
        m_sendData[0].reserve(32);
        m_sendData[1].reserve(32);

        m_noteInfo.resize(128);
    }
    const char* GetName() const override { return "MIDI"; }

protected:
    uint8_t m_recvData[RECVDATA_SIZE];
    uint64_t m_sendActiveNotifyTime = 0;
    uint64_t m_recvActiveNotifyTime = 0;
    uint64_t m_lastChangeTime = 0;
    int32_t m_progNum = -1;
    float m_targetNote = 0.0f;
    float m_currentNote = 0.0f;
    int32_t m_waveIndex = -1;
    uint8_t m_recvNote = 0;
    uint8_t m_tempNote = 0;
    uint8_t m_lastNote = 0;
    uint16_t m_recvBreathH = 0;
    uint16_t m_recvBreathL = 0;
    uint16_t m_recvBreath = 0;
    uint16_t m_recvBend = 0;
    uint16_t m_tempBend = 0;
    uint8_t m_prevNote = 0;
    uint8_t m_channelNo = 1;
    uint8_t m_recvStatus = 0;
    uint8_t m_recvChannel = 0;
    uint8_t m_recvPos = 0;
    uint8_t m_recvMode = 0;
    bool m_playing = false;
    bool m_inputPlaying = false;
    bool m_recvActive = false;
    bool m_overflow = false;

    //--------
    void MIDI_UpdateInput(Parameters& params, Message& msg) {
        if (m_inputPlaying) {
            uint64_t t = millis();
            if (m_recvNote != m_lastNote) {
                m_lastNote = m_recvNote;
                m_lastChangeTime = t;
                msg.keepNoteTime = 0.0f;
            }
            {//if (t - m_lastChangeTime > params.keyDelay) { // ピロ音防止うまく動いてないので一旦コメントアウト
                m_targetNote = m_recvNote + (params.baseNote - 48.0f);
                if (params.info.dropPos > 0.0f && msg.volume < params.info.dropPos) { // 音量によるピッチダウン
                    m_targetNote -= (1.0f-(msg.volume / params.info.dropPos)) * params.info.dropAmount;
                }
            }
            m_currentNote += (m_targetNote - m_currentNote) * params.info.portamento;
            msg.note = m_currentNote;
            msg.bend = (m_recvBend - 8192.0f) / 8191.0f;
            float b = m_recvBreath / 16383.0f;
            msg.volume = b * b;
        }
        if (m_waveIndex >=0 && (m_waveIndex % params.GetWaveTableCount()) != params.GetWaveTableIndex()) {
            params.SetWaveTableIndex(m_waveIndex);
            m_waveIndex = -1;
        }
        if (m_overflow) {
            params.SetDispMessage("OVERFLOW", 200);
        } else if (!m_recvActive) {
            //params.SetDispMessage("NO SIGNAL", 200);
        }
    }

    //--------
    void MIDI_UpdateOutput(Parameters& params, Message& msg) {
        uint64_t t = millis();
        if (t - m_sendActiveNotifyTime > 250) { // 300ms 以内に送信する
            m_sendActiveNotifyTime = t;
            ActiveNotify();
        }

        if (m_progNum != params.GetWaveTableIndex()) {
            m_progNum = params.GetWaveTableIndex();
            ProgramChange(m_progNum);
        }
        if (!m_playing) {
            if (msg.volume > 0.01f) {
                uint8_t note = static_cast<uint8_t>(Clamp(static_cast<int32_t>(msg.pureNote), 0, 127));
                uint16_t breath = static_cast<uint16_t>(sqrt(Clamp(msg.volume, 0.0f, 1.0f)) * 16383.0f);
                m_prevNote = note;
                BreathControl(0, params.breathMode);
                NoteOn(note, 120, false);
                //BreathControl(breath, params.breathMode);
                float b = 8192.0f + 8000.0f * msg.bend;
                uint16_t bend = static_cast<uint16_t>(b);
                PicthBendControl(bend);
            }
            else {
                //BreathControl(0, params.breathMode);
            }
        }
        else {
            if (msg.volume < 0.01f) {
                NoteOff(m_prevNote, 0);
            }
            else {
                int32_t note = static_cast<int32_t>(msg.pureNote);
                uint16_t breath = static_cast<uint16_t>(Clamp(msg.volume, 0.0f, 1.0f) * 16383.0f);
                if (note != m_prevNote) {
                    NoteOn(note, 120, true);
                    m_prevNote = note;
                }
                BreathControl(breath, params.breathMode);
                float b = 8192.0f + 8191.0f * msg.bend;
                uint16_t bend = static_cast<uint16_t>(b);
                PicthBendControl(bend);
            }
        }
        {
            int32_t i = m_sendCount % 2;

            if (m_sendData[i].size() > 0) {
                SendData(m_sendData[i].data(), m_sendData[i].size());
                m_sendCount++;
                m_sendData[m_sendCount%2].clear();
            }
        }
        if (!m_inputPlaying && params.beepTime == 0) {
            msg.volume = 0.0f; // 後続のスピーカーに渡さない
        }
    }

    //--------
    void ProcessReceivedData(size_t size) {
        uint64_t t = millis();
        if (size >= RECVDATA_SIZE) {
            return;
        }
        if (size > 0) {
            m_recvActiveNotifyTime = t;
            m_recvActive = true;
        }
        for (size_t i = 0; i < size; i++) {
            uint8_t d = m_recvData[i];
            if (d >= 0x80) {
                if (d >= 0xF8) {
                    continue; // ActiveNotify などは RunningStatus を維持
                }
                m_recvStatus = d & 0xF0;
                m_recvChannel = d & 0x0F;
                m_recvPos = 0;
                m_recvMode = 0;
                continue;
            }
            switch (m_recvStatus) {
                case 0x80:
                    {
                        switch (m_recvPos) {
                            default:
                                m_tempNote = d;
                                break;
                            case 1:
                                m_noteInfo[m_tempNote].velocity = 0;
                                for (uint8_t i = 0; i < 128; i++) {
                                    if (m_noteInfo[i].velocity > 0) {
                                        m_recvNote = i;
                                        break;
                                    }
                                }
                                break;
                        }
                        m_recvPos = (m_recvPos + 1) % 2;
                    }
                break;
                case 0x90:
                    {
                        switch (m_recvPos) {
                            default:
                                m_tempNote = d;
                                break;
                            case 1:
                                m_noteInfo[m_tempNote].velocity = d;
                                for (uint8_t i = 0; i < 128; i++) {
                                    if (m_noteInfo[i].velocity > 0) {
                                        m_inputPlaying = true;
                                        m_recvNote = i;
                                        break;
                                    }
                                }
                                break;
                        }
                        m_recvPos = (m_recvPos + 1) % 2;
                    }
                break;
                case 0xB0:
                    {
                        switch (m_recvPos) {
                            default:
                                m_recvMode = d;
                                break;
                            case 1:
                                if (m_recvMode == 0x02 || m_recvMode == 0x0B || m_recvMode == 0x07) {
                                    m_recvBreathH = d;
                                    m_recvBreath = (m_recvBreathH << 7) | m_recvBreathL;
                                }
                                else if (m_recvMode == 0x22 || m_recvMode == 0x2B || m_recvMode == 0x27) {
                                    m_recvBreathL = d;
                                    m_recvBreath = (m_recvBreathH << 7) | m_recvBreathL;
                                }
                                break;
                        }
                        m_recvPos = (m_recvPos + 1) % 2;
                    }
                break;
                case 0xC0:
                    // Program Change
                    {
                        m_waveIndex = d;
                    }
                break;
                case 0xD0:
                    // AfterTouch(Channel Pressure)
                break;
                case 0xE0:
                    // Pitch Bend Change
                    {
                        switch (m_recvPos) {
                            default:
                                m_tempBend = d;
                                break;
                            case 1:
                                m_recvBend = (d << 7) | m_tempBend;
                                break;
                        }
                        m_recvPos = (m_recvPos + 1) % 2;
                    }
                break;
            }
        }
        if (m_recvActiveNotifyTime > 0 && t - m_recvActiveNotifyTime > 500) { // 300ms 以内に来るはず
            m_recvActiveNotifyTime = t;
            m_recvActive = false;
            m_recvBreath = 0;
            m_recvBreathH = 0;
            m_recvBreathL = 0;
            m_inputPlaying = false;
            m_overflow = false;
        }
    }

    //--------
    void NoteOn(uint8_t note, uint8_t velocity, bool changeNote) {
        PushStatus(0x90 + m_channelNo);
        PushData(note, velocity);
        if (changeNote) {
            //PushData(m_prevNote, 0); // NoteOn(Velocity=0) だと SEM で正しく切り替わらないので NoteOff を使う
            NoteOff(m_prevNote, 0);
        }
        m_playing = true;
    }
    //--------
    void NoteOff(uint8_t note, uint8_t velocity) {
        m_playing = false;
        PushStatus(0x80 + m_channelNo);
        PushData(note, velocity);
    }
    //--------
    void PicthBendControl(uint16_t bend) {
        uint8_t d0 = bend & 0x7F;
        uint8_t d1 = (bend >> 7) & 0x7F;
        PushStatus(0xE0 + m_channelNo);
        PushData(d0, d1);
    }
    //--------
    void BreathControl(uint16_t vol, MIDIBreathMode mode) {
        switch (mode) {
            case MIDIBreathMode::BreathControl:
                PushStatus(0xB0 + m_channelNo);
                PushData(0x02, static_cast<uint8_t>((vol >> 7) & 0x7F));
                //PushData(0x22, static_cast<uint8_t>(vol & 0x7F));
                return;
            case MIDIBreathMode::Expression:
                PushStatus(0xB0 + m_channelNo);
                PushData(0x0B, static_cast<uint8_t>((vol >> 7) & 0x7F));
                //PushData(0x2B, static_cast<uint8_t>(vol & 0x7F));
                return;
            case MIDIBreathMode::AfterTouch: // Channel Pressure
                PushStatus(0xD0 + m_channelNo);
                PushData(static_cast<uint8_t>((vol >> 7) & 0x7F));
                return;
            case MIDIBreathMode::MainVolume: // Channel Volume
                PushStatus(0xB0 + m_channelNo);
                PushData(0x07, static_cast<uint8_t>((vol >> 7) & 0x7F));
                //PushData(0x27, static_cast<uint8_t>(vol & 0x7F));
                return;
            case MIDIBreathMode::CutOff: // Brightness
                PushStatus(0xB0 + m_channelNo);
                PushData(0x4A, static_cast<uint8_t>((vol >> 7) & 0x7F));
                return;
        }
    }
    //--------
    void ProgramChange(uint8_t pgNum) {
        PushStatus(0xC0 + m_channelNo);
        PushData(pgNum);
    }
    //--------
    void ActiveNotify() {
        PushData(0xFE);
    }

    //--------
    void PushStatus(int32_t status) {
        if (status != m_status) {
            m_sendData[m_sendCount%2].push_back(static_cast<uint8_t>(status));
            m_status = status;
        }
    }

    //--------
    void PushData(int32_t data0, int32_t data1 = -1, int32_t data2 = -1, int32_t data3 = -1) {
        m_sendData[m_sendCount%2].push_back(static_cast<uint8_t>(data0));
        if (data1 >= 0) {
            m_sendData[m_sendCount%2].push_back(static_cast<uint8_t>(data1));
        }
        if (data2 >= 0) {
            m_sendData[m_sendCount%2].push_back(static_cast<uint8_t>(data2));
        }
        if (data3 >= 0) {
            m_sendData[m_sendCount%2].push_back(static_cast<uint8_t>(data3));
        }
    }

    //--------
    virtual void SendData(const uint8_t* buff, size_t size) = 0;

private:
    struct NoteInfo {
        uint8_t velocity = 0;
    };

    //--------
    float GetRate(float value, float min, float max) {
        if (max <= min) {
            return 0;
        }
        float v = Clamp(value, min, max) - min;
        return v / (max - min);
    }

    std::vector<NoteInfo> m_noteInfo;
    std::vector<uint8_t> m_sendData[2];
    int32_t m_sendCount = 0;
    int32_t m_status = 0;
};

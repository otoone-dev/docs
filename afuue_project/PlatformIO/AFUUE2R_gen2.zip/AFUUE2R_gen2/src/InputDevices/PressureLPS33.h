#pragma once
#include <Wire.h>
#include "InputDeviceBase.h"
#include <string>
#include <format>

#define LPS33_ADDR (0x5C)
#define LPS33_WHOAMI_REG (0x0F)
#define LPS33_WHOAMI_RET (0xB1)
#define LPS33_REG_CTRL (0x10)
#define LPS33_REG_OUT_XL (0x28)

class PressureLPS33 : public InputDeviceBase {
public:
    enum class ReadType : uint8_t {
        BREATH, // addr=0x5C
        BREATH_AND_BEND,   // addr=0x5D
    };

    //--------------
    PressureLPS33(TwoWire &wire, ReadType readType) 
        : m_wire(wire)
        , m_address(LPS33_ADDR)
        , m_readType(readType) {}

    //--------------
    const char* GetName() const override {
        return "LPS33";
    }

    //--------------
    InitializeResult Initialize(Parameters& params) override {
        InitializeResult result;
        delay(100);
        result = StartDevice(m_address); // BREATH
        if (result.success && m_readType == ReadType::BREATH_AND_BEND) {
            delay(10);
            result = StartDevice(m_address + 1); // BEND
        }
        delay(100);
        if (result.success) {
            m_defaultPressure = GetPressure(m_address) + 50.0f;
            m_currentPressure = m_defaultPressure;
            if (m_readType == ReadType::BREATH_AND_BEND) {
                delay(10);
                m_defaultBendPressure = GetPressure(m_address + 1) + 50.0f;
                m_currentBendPressure = m_defaultBendPressure;
            }
        }
        return result;
    }

    //--------------
    bool UpdateInput(Parameters& params, Message& msg) override {
        float p = GetPressure(m_address); // 16300 - 17300 くらい
        float currentPressure = (p - m_defaultPressure) * params.breathSense;
        m_currentPressure += (currentPressure - m_currentPressure) * 0.5f;
        float v = Clamp(m_currentPressure, 0.0f, 1.0f);
        msg.volume = v * v;
        if (m_readType == ReadType::BREATH_AND_BEND && params.IsBendEnabled()) {
            float currentBendPressure = (GetPressure(m_address + 1) - m_defaultBendPressure) * params.breathSense; //ブレスと同じでないとズレる
            m_currentBendPressure += (currentBendPressure - m_currentBendPressure) * 0.5f;
            float vb = Clamp(m_currentBendPressure, 0.0f, 1.0f);
            float bendNoteShiftTarget = 0.0f;
            if (abs(v) > 0.00001f || abs(vb) > 0.00001f) {
                if (v >= vb && v > 0.0001f) {
                    msg.ext = 0.0f;
                    bendNoteShiftTarget = -1.0f + ((v - vb) / v) * 1.2f;
                    if (bendNoteShiftTarget > 0.0f) {
                        bendNoteShiftTarget = 0.0f;
                    }
                }
                else if (vb >= v && vb > 0.00001f) {
                    float f = (vb - v) / vb;
                    msg.ext = Clamp(f, 0.0f, 1.0f);
                    bendNoteShiftTarget = -1.0f + f * 1.2f;
                    if (bendNoteShiftTarget > 0.0f) {
                        bendNoteShiftTarget = 0.0f;
                    }
                    msg.volume = vb;
                }
            }
            else {
                bendNoteShiftTarget = 0.0f;
            }
            msg.bend = bendNoteShiftTarget;
        }
        else {
            msg.bend = 0.0f;
        }
#ifdef DEBUG
        //char s[64];
        //sprintf(s, "%1.1f\n%1.1f\n%1.1fB\n%1.1fB\n%1.1f", m_currentPressure, m_defaultPressure, m_currentBendPressure, m_defaultBendPressure, v);
        //params.SetDispMessage(s, 100);
#endif
        return true;
    }
private:
    TwoWire &m_wire;
    int m_address;
    float m_defaultPressure = 0.0f;
    float m_currentPressure = 0.0f;
    float m_defaultBendPressure = 0.0f;
    float m_currentBendPressure = 0.0f;
    ReadType m_readType;

    //--------------
    InitializeResult StartDevice(int address) {
        InitializeResult result;
        if (!CheckDevice(m_wire, address)) {
            result.success = false;
            result.errorMessage = std::format("NO LPS33:{0}", address);
            return result;
        }
        m_wire.beginTransmission(address);
        m_wire.write(LPS33_WHOAMI_REG);
        m_wire.endTransmission();
        m_wire.requestFrom(address, 1);
        uint8_t whoami = m_wire.read();
        if (whoami != LPS33_WHOAMI_RET) {
            result.success = false;
            result.errorMessage = std::format("LPS33 ERR:{0}", address);
            return result;
        }
        m_wire.beginTransmission(address);
        m_wire.write(LPS33_REG_CTRL);
        m_wire.write(0x50); // odr (0x50=75Hz, 0x40=50Hz, 0x30=25Hz, 0x20=10Hz, 0x10=1Hz, 0x00=OFF)
        m_wire.endTransmission();
        return result;
    }

    //--------------
    float GetPressure(int address) {
        Wire.beginTransmission(address);
        Wire.write(LPS33_REG_OUT_XL);
        Wire.endTransmission();
        Wire.requestFrom(address, 3);

        uint8_t data[3];
        for (int i = 0; i < 3; i++) {
            data[i] = Wire.read();
        }        
        uint32_t pressure = ((((uint32_t)data[2]) << 16) | (((uint32_t)data[1]) << 8) | data[0]);
        return pressure * 0.0015f; // 1/4096 で hPa 単位だが、他に合わせるため調整
    }
};

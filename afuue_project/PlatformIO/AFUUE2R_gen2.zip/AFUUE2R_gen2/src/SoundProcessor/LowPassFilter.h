#pragma once

#include "SoundProcessorBase.h"
#include <cmath>

class LowPassFilter : public SoundProcessorBase {
public:
    //--------------
    LowPassFilter()
    {}
    //--------------
    void Initialize(const Parameters& params) override {
    }

    //--------------
    // 波形更新（高速呼び出しされる）
    void ProcessAudio(SoundInfo& info) override {
        if (m_lp_a0 != 0.0f) {
            info.wave = LowPass(info.wave);
        }
    }

    #define NOTECHANGE_FILTER_TIME (0.1f)
    //--------------
    // パラメータ更新（低速呼び出しされる)
    void UpdateParameter(Parameters& params, Message& msg) override {
        if (params.info.lowPassQ > 0.0f) {
            float idQ = 1.0f / (2.0f * (params.info.lowPassQ));
            float t = (msg.keepNoteTime < 0.1f
                ? -params.info.lowPassN + params.info.lowPassN * TableSine(Clamp(msg.keepNoteTime, 0.0f, NOTECHANGE_FILTER_TIME) / NOTECHANGE_FILTER_TIME * 0.25f) // sin の 1/4 だけ使うので x0.25
                : 0.0f);
            float a = (tanh(params.info.lowPassR * (msg.volume - params.info.lowPassP + t*msg.volume)) + 1.0f) * 0.5f;
            float lp = params.filterFreqMin + (params.filterFreqMax - params.filterFreqMin) * a;
            if (lp > params.filterFreqMax) {
                lp = params.filterFreqMax;
            }
            m_lp_value += (lp - m_lp_value) * 0.5f;

            float omega = m_lp_value / params.samplingRate;
            float alpha = TableSine(omega) * idQ;
            float cosv = TableSine(omega + 0.25f);
            float one_minus_cosv = 1.0f - cosv;
            m_lp_a0 =  1.0f + alpha;
            m_lp_a1 = -2.0f * cosv;
            m_lp_a2 =  1.0f - alpha;
            m_lp_b0 = one_minus_cosv * 0.5f;
            m_lp_b1 = one_minus_cosv;
            m_lp_b2 = m_lp_b0;
        }
    }

private:
    float m_lp_value = 0.0f;

    float m_lp_in1 = 0.0f;
    float m_lp_in2 = 0.0f;
    float m_lp_out1 = 0.0f;
    float m_lp_out2 = 0.0f;

    float m_lp_a0 = 1.0f;
    float m_lp_a1 = 0.0f;
    float m_lp_a2 = 0.0f;
    float m_lp_b0 = 0.0f;
    float m_lp_b1 = 0.0f;
    float m_lp_b2 = 0.0f;

    //--------------
    float LowPass(float value) { 
        float lp = (m_lp_b0 * value 
                    + m_lp_b1 * m_lp_in1 
                    + m_lp_b2 * m_lp_in2
                    - m_lp_a1 * m_lp_out1
                    - m_lp_a2 * m_lp_out2) / m_lp_a0;

        m_lp_in2  = m_lp_in1;
        m_lp_in1  = value;
        m_lp_out2 = m_lp_out1;
        m_lp_out1 = lp;
        return lp;
    }

};

#include "SoundProcessorBase.h"
#include <vector>

class WaveGenerator : public SoundProcessorBase {
public:
    //--------------
    WaveGenerator() 
        : m_waveIndex(0)
        , m_phase(0.0f) {}

    //--------------
    void Initialize(const Parameters& params) override {
        // Preferences からデータ復帰したり？
        m_waveIndex = params.GetWaveTableIndex();
        m_pWaveTable = params.info.pWave;
    }

    //--------------
    // 波形更新（高速呼び出しされる）
    void ProcessAudio(SoundInfo& info) override {
        m_phase += info.tickCount;
        if (m_phase >= 1.0f) m_phase -= 1.0f;
        if (!m_phaseLock || (rand()%100 > 20)) {
            if (!info.squareBeep) {
                info.wave = InteropL(m_pWaveTable, 256, m_phase) * info.volume;
            }
            else {
                info.wave = (m_phase < 0.5f ? info.volume : -info.volume);
                info.skip = true;
            }
        }
    }

    //--------------
    // パラメータ更新（低速呼び出しされる)
    void UpdateParameter(Parameters& params, Message& msg) override {
        int i = params.GetWaveTableIndex() % params.GetWaveTableCount();
        if (m_waveIndex != i) {
            m_waveIndex = i;
            m_pWaveTable = params.info.pWave;
        }
        m_phaseLock = (msg.ext > 0.5f);
        if (m_phaseLock) {
            int r = rand() % 100;
            if (r < 10) {
                msg.volume = 0.2f;
            }
        }
    }
private:
    int m_waveIndex;
    float m_phase;
    const float* m_pWaveTable;
    bool m_phaseLock = false;
};

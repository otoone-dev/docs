#pragma once

#include "SoundProcessorBase.h"
#include <math.h>

class LFO : public SoundProcessorBase {
public:
    //--------------
    LFO()
        : m_power(0.0f)
        , m_freq(1.0f)
    {
    }

    //--------------
    void Initialize(const Parameters& params) override {
    }

    //--------------
    // 波形更新（高速呼び出しされる）
    void ProcessAudio(SoundInfo& info) override {
    }
    //--------------
    // パラメータ更新（低速呼び出しされる)
    void UpdateParameter(Parameters& params, Message& msg) override {
        m_power = params.info.lfoPower * msg.volume;
        m_freq = params.info.lfoFreq;
        if (m_power > 0.0f) {
            if (msg.playTime > params.info.lfoDelay) {
                float i = Clamp((msg.playTime - params.info.lfoDelay) / 0.5f, 0.0f, 1.0f);
                float t = static_cast<int32_t>(millis()) / 1000.0f;
                float nn = msg.note + i * m_power * TableSine(m_freq * t);
                float n = Clamp(nn, 1.0f, 127.0f);
                msg.note = n;
            }
        }
    }

private:
    float m_power;
    float m_freq;
};
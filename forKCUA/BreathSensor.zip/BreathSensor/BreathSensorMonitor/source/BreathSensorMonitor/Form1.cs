﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Threading;

namespace BreathSensorMonitor
{
    public partial class Form1 : Form
    {
        private SerialPort serialPort = new SerialPort();
        private int[] data = new int[64];
        private int[] data2 = new int[64];
        private int dpos = 0;
        private int pdata = 0;
        private Font font = new Font("Impact", 40);
        private int peek = 0;
        private int ave = 0;
        private int dSum = 0;
        private int aveTimer = 0;
        private const int aveTime = 5;
        private int holdTimer = 0;
        private const int holdTime = 30;
        private int sysCount = 0;
        private const int zeroOffset = 20;
        public struct SaveData {
            public int range;
            public int min;
            public int max;
        }

        //----------------
        public Form1()
        {
            InitializeComponent();
            this.Text = "Breath Sensor Monitor";
            string saveFileName = System.IO.Path.ChangeExtension(Application.ExecutablePath, ".xml");
            if (System.IO.File.Exists(saveFileName))
            {
                System.Xml.Serialization.XmlSerializer serializer =
                    new System.Xml.Serialization.XmlSerializer(typeof(SaveData));
                System.IO.StreamReader sr = new System.IO.StreamReader(
                    saveFileName, new System.Text.UTF8Encoding(false));
                SaveData saveData = (SaveData)serializer.Deserialize(sr);
                numericUpDown1.Value = saveData.min;
                numericUpDown2.Value = saveData.max;
                numericUpDown3.Value = saveData.range;
                sr.Close();
            }
        }

        //----------------
        private void push_data(int d)
        {
            if (d > peek)
            {
                peek = d;
                holdTimer = holdTime;
            }
            else
            {
                if (holdTimer > 0)
                {
                    holdTimer--;
                }
                else
                {
                    peek = d;
                    //holdTimer = holdTime;
                }
            }
            dSum += d;
            aveTimer++;
            if (aveTimer >= aveTime)
            {
                aveTimer = 0;
                ave = (int)(dSum / (double)aveTime);
                dSum = 0;
            }
            data[dpos] = d;
            dpos = (dpos + 1) % data.Length;

            this.Invalidate();
        }

        //----------------
        private void timer1_Tick(object sender, EventArgs e)
        {
            sysCount++;
            if (serialPort.IsOpen == false)
            {
                push_data(0);
                //push_data((int)(100 + 100 * Math.Sin(sysCount * 0.1)));
                return;
            }
            try
            {
                for (int i = 0; i < 4; i++) // 1/10s 毎に ---, 吹き込み量の推測値, 気圧(センサーからの値), 温度(センサーからの値) の４回送信されてくる
                {
                    string s = serialPort.ReadLine().Replace("\r", "");
                    if (s == "---")
                    {
                        pdata = 0;
                    }
                    else if (s != "")
                    {
                        if (pdata == 0)
                        {
                            int d = Int32.Parse(s);
                            push_data(d);
                        }
                        pdata++;
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        //----------------
        private int ValueToPos(double v)
        {
            int w = this.ClientSize.Width;
            int h = this.ClientSize.Height;

            double range = (double)numericUpDown3.Value;
            if (range < 100)
            {
                range = 100;
            }
            double yrate = ((double)h - zeroOffset) / range;

            int y = (int)(v * yrate + zeroOffset);
            return h - y;
        }

        //----------------
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Color.FromArgb(25, 25, 30));

            int w = this.ClientSize.Width;
            int h = this.ClientSize.Height;
            double xrate = ((double)w - zeroOffset) / (data.Length - 1);

            int range = (int)numericUpDown3.Value;
            if (range < 100)
            {
                range = 100;
            }

            Pen gridPen = new Pen(new SolidBrush(Color.FromArgb(40, 40, 40)));
            for (int i = 1; i < range/10; i++)
            {
                int v = i * 100;
                int y = ValueToPos(v);
                g.DrawLine(gridPen, new Point(0, y), new Point(w, y));
            }

            int currentValue = data[(dpos + data.Length - 1) % data.Length];
            Brush validBrush = new SolidBrush(Color.FromArgb(30, 50, 80));
            if (((int)numericUpDown1.Value <= currentValue) && (currentValue <= (int)numericUpDown2.Value)) {
                validBrush = new SolidBrush(Color.FromArgb(40, 60, 150));
            }
            {
                int y0 = ValueToPos((double)numericUpDown2.Value);
                int y1 = ValueToPos((double)numericUpDown1.Value);
                g.FillRectangle(validBrush, new Rectangle(0, y0, w, y1 - y0));
            }

            int zy = ValueToPos(0);
            g.DrawLine(new Pen(Brushes.DimGray), new Point(0, zy), new Point(w, zy));
            g.DrawLine(new Pen(Brushes.DimGray), new Point(w - zeroOffset, 0), new Point(w - zeroOffset, h));

            {
                int y = ValueToPos(peek);
                g.DrawLine(new Pen(Brushes.Red), new Point(0, y), new Point(w, y));
            }

            Pen valuePen = new Pen(new SolidBrush(Color.Lime), 3);
            for (int i = 0; i < data.Length-1; ++i)
            {
                int x0 = (int)(i * xrate);
                int x1 = (int)((i+1) * xrate);

                int pos = dpos + i;
                int d = data[(pos + 1) % data.Length];
                int y0 = ValueToPos(data[pos % data.Length]);
                int y1 = ValueToPos(d);

                g.DrawLine(valuePen, new Point(x0, y0), new Point(x1, y1));
            }

            g.DrawString(currentValue.ToString(), font, Brushes.Lime, new Point(20, 50));
            g.DrawString(peek.ToString(), font, Brushes.Red, new Point(20, 120));
            g.DrawString(ave.ToString(), font, Brushes.Yellow, new Point(20, 190));
        }

        //----------------
        private void OpenPort(string name)
        {
            if (serialPort.IsOpen)
            {
                serialPort.Close();
            }
            this.Text = "Breath Sensor Monitor ";
            serialPort.PortName = name;
            serialPort.BaudRate = 115200;
            serialPort.DataBits = 8;
            serialPort.Parity = Parity.None;
            serialPort.StopBits = StopBits.One;
            serialPort.Handshake = Handshake.None;
            serialPort.ReadTimeout = 1;

            try
            {
                serialPort.Open();
                this.Text += "(" + name + " Connected)";
            }
            catch (Exception ex)
            {
                this.Text += "(" + name + " Error)";
                MessageBox.Show(ex.Message);
            }
        }

        //----------------
        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            string[] PortList = SerialPort.GetPortNames();
            if (PortList.Length == 0) return;

            foreach (var port in PortList)
            {
                comboBox1.Items.Add(port);
            }
            comboBox1.SelectedIndex = 0;
        }

        //----------------
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (serialPort.IsOpen)
            {
                serialPort.Close();
            }

            SaveData saveData;
            saveData.min = (int)numericUpDown1.Value;
            saveData.max = (int)numericUpDown2.Value;
            saveData.range = (int)numericUpDown3.Value;
            string saveFileName = System.IO.Path.ChangeExtension(Application.ExecutablePath, ".xml");
            System.Xml.Serialization.XmlSerializer serializer =
                new System.Xml.Serialization.XmlSerializer(typeof(SaveData));
            System.IO.StreamWriter sw = new System.IO.StreamWriter(
                saveFileName, false, new System.Text.UTF8Encoding(false));
            serializer.Serialize(sw, saveData);
            sw.Close();
        }

        //----------------
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            OpenPort(comboBox1.SelectedItem.ToString());
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Threading;

namespace BreathSensorMonitor
{
    public partial class Form1 : Form
    {
        private SerialPort serialPort = new SerialPort();
        private int[] data = new int[64];
        private int[] data2 = new int[64];
        private int dpos = 0;
        private int pdata = 0;
        private Font font = new Font("Meiryo UI", 40);
        private int peek = 0;
        private const int holdTime = 20;
        private int holdTimer = 0;

        //----------------
        public Form1()
        {
            InitializeComponent();
            this.Text = "Breath Sensor Monitor";
        }

        //----------------
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (serialPort.IsOpen == false) return;

            try
            {
                for (int i = 0; i < 4; i++) // 1/10s 毎に ---, 吹き込み量の推測値, 気圧(センサーからの値), 温度(センサーからの値) の４回送信されてくる
                {
                    string s = serialPort.ReadLine().Replace("\r", "");
                    if (s == "---")
                    {
                        pdata = 0;
                    }
                    else if (s != "")
                    {
                        if (pdata == 0)
                        {
                            int d = Int32.Parse(s);
                            if (d > peek)
                            {
                                peek = d;
                                holdTimer = holdTime;
                            }
                            else
                            {
                                if (holdTimer > 0)
                                {
                                    holdTimer--;
                                } else
                                {
                                    peek = d;
                                    holdTimer = holdTime;
                                }
                            }
                            data[dpos] = d;
                            dpos = (dpos + 1) % data.Length;
                        }
                        pdata++;
                    }
                }
            }
            catch (Exception ex)
            {

            }

            this.Invalidate();
        }

        //----------------
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Color.FromArgb(5, 5, 10));

            int ofs = 20;
            int w = this.ClientSize.Width;
            int h = this.ClientSize.Height;

            double range = 1000;
            double xrate = ((double)w - ofs) / (data.Length - 1);
            double yrate = ((double)h - ofs) / range;

            Pen gridPen = new Pen(new SolidBrush(Color.FromArgb(20, 20, 20)));
            for (int i = 1; i < 10; i++)
            {
                int v = i * 100;
                int y = (int)(v * yrate + ofs);
                g.DrawLine(gridPen, new Point(0, h - y), new Point(w, h - y));
            }
            g.DrawLine(new Pen(Brushes.DimGray), new Point(0, h - ofs), new Point(w, h - ofs));
            g.DrawLine(new Pen(Brushes.DimGray), new Point(w - ofs, 0), new Point(w - ofs, h));

            {
                int y = (int)(peek * yrate + ofs);
                g.DrawLine(new Pen(Brushes.Red), new Point(0, h - y), new Point(w, h - y));
            }

            Pen valuePen = new Pen(new SolidBrush(Color.Lime), 2);
            for (int i = 0; i < data.Length-1; ++i)
            {
                int x0 = (int)(i * xrate);
                int x1 = (int)((i+1) * xrate);

                int pos = dpos + i;
                int y0 = h - (int)((data[pos % data.Length]) * yrate + ofs);
                int y1 = h - (int)((data[(pos + 1) % data.Length]) * yrate + ofs);

                g.DrawLine(valuePen, new Point(x0, y0), new Point(x1, y1));
            }

            g.DrawString(data[(dpos + data.Length - 1) % data.Length].ToString(), font, Brushes.Lime, new Point(20, 50));
            g.DrawString(peek.ToString(), font, Brushes.Red, new Point(20, 120));
        }

        //----------------
        private void OpenPort(string name)
        {
            if (serialPort.IsOpen)
            {
                serialPort.Close();
            }
            this.Text = "Breath Sensor Monitor ";
            serialPort.PortName = name;
            serialPort.BaudRate = 115200;
            serialPort.DataBits = 8;
            serialPort.Parity = Parity.None;
            serialPort.StopBits = StopBits.One;
            serialPort.Handshake = Handshake.None;
            serialPort.ReadTimeout = 1;

            try
            {
                serialPort.Open();
                this.Text += "(" + name + " Connected)";
            }
            catch (Exception ex)
            {
                this.Text += "(" + name + " Error)";
                MessageBox.Show(ex.Message);
            }
        }

        //----------------
        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            string[] PortList = SerialPort.GetPortNames();
            if (PortList.Length == 0) return;

            foreach (var port in PortList)
            {
                comboBox1.Items.Add(port);
            }
            comboBox1.SelectedIndex = 0;
        }

        //----------------
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (serialPort.IsOpen)
            {
                serialPort.Close();
            }
        }

        //----------------
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            OpenPort(comboBox1.SelectedItem.ToString());
        }
    }
}
